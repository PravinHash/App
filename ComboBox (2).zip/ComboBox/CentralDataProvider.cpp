#include "CentralDataProvider.h"

CentralDataProvider::CentralDataProvider(QObject *parent)
    : QObject(parent)
{
    buildCentralData();
}

QVariantMap CentralDataProvider::centralData() const {
    return m_centralData;
}

void CentralDataProvider::buildCentralData() {
    // Classification List
    m_centralData["classification"] = QVariantList{"Air", "Land", "Unknown"};

    // Items
    QVariantList items;

    // Helper: Parameters List
    auto makeParams = []() -> QVariantList {
        return QVariantList{
            QVariantMap{{"name", "param1"}, {"value", "0.2"}},
            QVariantMap{{"name", "param2"}, {"value", "0.1"}},
            QVariantMap{{"name", "param3"}, {"value", "0.3"}},
            QVariantMap{{"name", "param4"}, {"value", "0.4"}}
        };
    };

    // Helper: Create children
    auto makeChildren = [&makeParams](const QString &baseName) -> QVariantList {
        return QVariantList{
            QVariantMap{{"name", baseName}, {"color", "gray"}, {"parameters", makeParams()}}
        };
    };

    items.append(QVariantMap{{"name", "001"}, {"color", "yellow"}, {"category", "Radar"},
                             {"classification", "Land"}, {"treeCategory", "Raw"},
                             {"nominate", true}, {"promote", false},
                             {"parameters", makeParams()},
                             {"children", makeChildren("Item2.1")}});

    items.append(QVariantMap{{"name", "002"}, {"color", "green"}, {"category", "Radar"},
                             {"classification", "Land"}, {"treeCategory", "Raw"},
                             {"nominate", false}, {"promote", false},
                             {"parameters", makeParams()},
                             {"children", makeChildren("Item2.1")}});

    items.append(QVariantMap{{"name", "003"}, {"color", "red"}, {"category", "Sonar"},
                             {"classification", "Air"}, {"treeCategory", "Raw"},
                             {"nominate", true}, {"promote", true},
                             {"parameters", makeParams()},
                             {"children", QVariantList{
                                              QVariantMap{{"name", "Item1.1"}, {"color", "green"}, {"parameters", makeParams()}},
                                              QVariantMap{{"name", "Item1.2"}, {"color", "pink"}, {"parameters", makeParams()}}
                                          }}});

    items.append(QVariantMap{{"name", "004"}, {"color", "gray"}, {"category", "Sonar"},
                             {"classification", "Air"}, {"treeCategory", "Raw"},
                             {"nominate", false}, {"promote", true},
                             {"parameters", makeParams()},
                             {"children", QVariantList{
                                              QVariantMap{{"name", "Item1.1"}, {"color", "green"}, {"parameters", makeParams()}},
                                              QVariantMap{{"name", "Item1.2"}, {"color", "pink"}, {"parameters", makeParams()}}
                                          }}});

    items.append(QVariantMap{{"name", "005"}, {"color", "yellow"}, {"category", "AIS"},
                             {"classification", "Land"}, {"treeCategory", "Raw"},
                             {"nominate", true}, {"promote", true}, {"adopt", true},
                             {"parameters", makeParams()},
                             {"children", makeChildren("Item2.1")}});

    items.append(QVariantMap{{"name", "AS1001"}, {"color", "yellow"}, {"category", "AIS"},
                             {"classification", "Unknown"}, {"treeCategory", "Sensor"},
                             {"nominate", false},
                             {"parameters", makeParams()},
                             {"children", makeChildren("Item3.1")}});

    items.append(QVariantMap{{"name", "AS1001"}, {"color", "pink"}, {"category", "AIS"},
                             {"classification", "Unknown"}, {"treeCategory", "Sensor"},
                             {"nominate", false},
                             {"parameters", makeParams()},
                             {"children", makeChildren("Item4.1")}});

    m_centralData["Items"] = items;

    // Tree Category Data
    QVariantList treeCategoryData;

    treeCategoryData.append(QVariantMap{
        {"name", "Raw"},
        {"category", QVariantList{"Radar", "Sonar", "AIS", "Periscope", "Datalink"}},
        {"classification", QVariantList{"Unknown", "Land", "Air"}}
    });

    treeCategoryData.append(QVariantMap{
        {"name", "Sensor"},
        {"category", QVariantList{"Radar", "Sonar", "AIS", "Periscope"}},
        {"classification", QVariantList{"Unknown", "Land", "Air"}}
    });

    m_centralData["treeCategoryData"] = treeCategoryData;

    emit centralDataChanged();
}
