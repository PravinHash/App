#include "TrackItem.h"

TreeItem::TreeItem(const QVariantMap &data, TreeItem *parent)
    : m_data(data), m_parentItem(parent) {}

TreeItem::~TreeItem() {
    qDeleteAll(m_childItems);
}

void TreeItem::appendChild(TreeItem *child) {
    child->m_parentItem = this;
    m_childItems.append(child);
}

TreeItem *TreeItem::child(int row) const {
    return (row >= 0 && row < m_childItems.size()) ? m_childItems.at(row) : nullptr;
}

int TreeItem::childCount() const {
    return m_childItems.size();
}

int TreeItem::row() const {
    if (m_parentItem)
        return m_parentItem->m_childItems.indexOf(const_cast<TreeItem *>(this));
    return 0;
}

TreeItem *TreeItem::parentItem() const {
    return m_parentItem;
}

QVariantMap TreeItem::data() const {
    return m_data;
}

int TreeItem::depth() const {
    int d = 0;
    const TreeItem *p = m_parentItem;
    while (p) {
        d++;
        p = p->parentItem();
    }
    return d;
}

void TreeItem::updateData(const QVariantMap &newData) {
    for (auto it = newData.constBegin(); it != newData.constEnd(); ++it) {
        if (it.key() != "children")  // avoid overwriting children during update
            m_data[it.key()] = it.value();
    }
}

