#include "TrackTreeModel.h"
#include <QDebug>

TrackTreeModel::TrackTreeModel(QObject *parent)
    : QAbstractItemModel(parent) {
    rootItem = new TreeItem({ {"id", "root"} });
    setupModelData();
}

TrackTreeModel::~TrackTreeModel() {
    delete rootItem;
}

int TrackTreeModel::columnCount(const QModelIndex &) const {
    return 1;
}

QVariant TrackTreeModel::data(const QModelIndex &index, int role) const {
    if (!index.isValid()) return {};

    TreeItem *item = getItem(index);
    QVariantMap d = item->data();

    switch (role) {
    case Qt::DisplayRole: return d.value("id");
    case Qt::UserRole + 1: return d.value("sensor");
    case Qt::UserRole + 2: return d.value("category");
    case Qt::UserRole + 3: return d.value("type");
    case Qt::UserRole + 4: return d;  // full data
    case Qt::UserRole + 5: return item->depth();
    default: return {};
    }
}

Qt::ItemFlags TrackTreeModel::flags(const QModelIndex &index) const {
    return index.isValid() ? Qt::ItemIsEnabled | Qt::ItemIsSelectable : Qt::NoItemFlags;
}

QVariant TrackTreeModel::headerData(int section, Qt::Orientation orientation, int role) const {
    return (orientation == Qt::Horizontal && role == Qt::DisplayRole) ? QString("Track ID") : QVariant();
}

QModelIndex TrackTreeModel::index(int row, int column, const QModelIndex &parent) const {
    if (!hasIndex(row, column, parent)) return {};

    TreeItem *parentItem = getItem(parent);
    TreeItem *childItem = parentItem->child(row);
    return childItem ? createIndex(row, column, childItem) : QModelIndex();
}

QModelIndex TrackTreeModel::parent(const QModelIndex &index) const {
    if (!index.isValid()) return {};

    TreeItem *childItem = getItem(index);
    TreeItem *parentItem = childItem->parentItem();
    return (parentItem && parentItem != rootItem) ? createIndex(parentItem->row(), 0, parentItem) : QModelIndex();
}

int TrackTreeModel::rowCount(const QModelIndex &parent) const {
    TreeItem *parentItem = getItem(parent);
    return parentItem ? parentItem->childCount() : 0;
}

TreeItem *TrackTreeModel::getItem(const QModelIndex &index) const {
    return index.isValid() ? static_cast<TreeItem *>(index.internalPointer()) : rootItem;
}

QHash<int, QByteArray> TrackTreeModel::roleNames() const {
    return {
        { Qt::DisplayRole, "display" },
        { Qt::UserRole + 1, "sensor" },
        { Qt::UserRole + 2, "category" },
        { Qt::UserRole + 3, "type" },
        { Qt::UserRole + 4, "fullData" },
        { Qt::UserRole + 5, "depth" }
    };
}

void TrackTreeModel::setupModelData() {
    addTrack({{"id", "MN001"}, {"type", "SENSOR"}, {"sensor", "Radar"}, {"category", "UNKNOWN"}});
    addTrack({{"id", "RD001"}, {"type", "SENSOR"}, {"sensor", "Radar"}, {"category", "UNKNOWN"}});
    addTrack({{"id", "RD003"}, {"type", "RAW"}, {"sensor", "Radar"}, {"category", "SURFACE"}});
    addTrack({
        {"id", "S001"}, {"type", "SYSTEM"}, {"sensor", "Sonar"}, {"category", "UNKNOWN"},
        {"children", QVariantList{
                         QVariantMap{{"id", "SN003"}, {"type", "SYSTEM"}, {"sensor", "Sonar"}, {"category", "UNKNOWN"}}
                     }}
    });
}

void TrackTreeModel::addTrack(const QVariantMap &trackData, TreeItem *parentItem) {
    if (!parentItem) parentItem = rootItem;

    TreeItem *trackItem = new TreeItem(trackData, parentItem);
    parentItem->appendChild(trackItem);

    if (trackData.contains("children")) {
        for (const QVariant &child : trackData["children"].toList()) {
            addTrack(child.toMap(), trackItem);
        }
    }
}

// void TrackTreeModel::addTrackFromCpp(const QVariantMap &trackData) {
//     if (!trackData.contains("id")) return;

//     TreeItem *parentItem = rootItem;
//     QModelIndex parentIndex = QModelIndex(); // root

//     int row = parentItem->childCount();
//     beginInsertRows(parentIndex, row, row);
//     addTrack(trackData, parentItem);
//     endInsertRows();


//     emit dataChanged(index(row, 0), index(row, 0));  // ⚠️ Notify new data

//     qDebug() << "[TrackTreeModel] Inserted track:" << trackData.value("id").toString();
// }

void TrackTreeModel::addTrackFromCpp(const QVariantMap &trackData) {
    if (!trackData.contains("id"))
        return;

    const QString id = trackData.value("id").toString();
    TreeItem *existingItem = findItemById(id, rootItem);

    if (existingItem) {
        existingItem->updateData(trackData);
        QModelIndex idx = createIndex(existingItem->row(), 0, existingItem);
        emit dataChanged(idx, idx);
        qDebug() << "[TrackTreeModel] Updated track:" << id;
        return;
    }

    TreeItem *parentItem = rootItem;
    QModelIndex parentIndex = QModelIndex();

    int row = parentItem->childCount();
    beginInsertRows(parentIndex, row, row);
    addTrack(trackData, parentItem);
    endInsertRows();

    qDebug() << "[TrackTreeModel] Inserted track:" << id;
}


TreeItem *TrackTreeModel::findItemById(const QString &id, TreeItem *parent) const {
    if (!parent) return nullptr;

    if (parent->data().value("id").toString() == id) {
        return parent;
    }

    for (int i = 0; i < parent->childCount(); ++i) {
        TreeItem *child = parent->child(i);
        TreeItem *result = findItemById(id, child);
        if (result)
            return result;
    }

    return nullptr;
}
