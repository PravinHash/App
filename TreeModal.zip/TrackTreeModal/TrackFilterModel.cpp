#include "TrackFilterModel.h"
#include <QAbstractItemModel>
#include <QDebug>

TrackFilterModel::TrackFilterModel(QObject *parent)
    : QSortFilterProxyModel(parent) {
    setDynamicSortFilter(true);
    setRecursiveFilteringEnabled(true);
    setFilterCaseSensitivity(Qt::CaseInsensitive);
}

QString TrackFilterModel::type() const { return m_type; }
QString TrackFilterModel::sensor() const { return m_sensor; }
QString TrackFilterModel::category() const { return m_category; }

void TrackFilterModel::setType(const QString &type) {
    if (m_type != type) {
        m_type = type;
        invalidateFilter();
        emit filterChanged();
    }
}

void TrackFilterModel::setSensor(const QString &sensor) {
    if (m_sensor != sensor) {
        m_sensor = sensor;
        invalidateFilter();
        emit filterChanged();
    }
}

void TrackFilterModel::setCategory(const QString &category) {
    if (m_category != category) {
        m_category = category;
        invalidateFilter();
        emit filterChanged();
    }
}

bool TrackFilterModel::filterAcceptsRow(int sourceRow, const QModelIndex &sourceParent) const {
    QModelIndex idx = sourceModel()->index(sourceRow, 0, sourceParent);
    if (!idx.isValid())
        return false;

    auto data = idx.data(Qt::UserRole + 4).toMap(); // fullData

    qDebug() << "[FilterModel] Filtering track:" << data.value("id").toString()
             << "Sensor:" << data.value("sensor").toString()
             << "Type:" << data.value("type").toString()
             << "Category:" << data.value("category").toString();

    return (m_type.isEmpty() || data.value("type") == m_type) &&
           (m_sensor.isEmpty() || data.value("sensor") == m_sensor) &&
           (m_category.isEmpty() || data.value("category") == m_category);
}

QHash<int, QByteArray> TrackFilterModel::roleNames() const {
    if (sourceModel())
        return sourceModel()->roleNames();
    return QSortFilterProxyModel::roleNames();
}
