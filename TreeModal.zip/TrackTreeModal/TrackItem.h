#ifndef TREEITEM_H
#define TREEITEM_H

#include <QVariantMap>
#include <QVector>

class TreeItem {
public:
    explicit TreeItem(const QVariantMap &data, TreeItem *parent = nullptr);
    ~TreeItem();

    void appendChild(TreeItem *child);
    TreeItem *child(int row) const;
    int childCount() const;
    int row() const;

    TreeItem *parentItem() const;
    QVariantMap data() const;
    int depth() const;

    void updateData(const QVariantMap &newData);


private:
    QVariantMap m_data;
    TreeItem *m_parentItem;
    QVector<TreeItem *> m_childItems;
};

#endif // TREEITEM_H
