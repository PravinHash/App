#include "xmlparser.h"
#include <QDomDocument>
#include <QFile>

XmlParser::XmlParser(QObject *parent) : QObject(parent) {}

QList<System> XmlParser::parseXml(const QString &filePath) {
    QList<System> systems;

    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qWarning() << "Failed to open XML file:" << filePath;
        return systems;
    }

    QDomDocument doc;
    if (!doc.setContent(&file)) {
        qWarning() << "Failed to parse XML file.";
        return systems;
    }

    QDomNodeList systemNodes = doc.elementsByTagName("System");
    for (int i = 0; i < systemNodes.size(); ++i) {
        QDomElement systemElement = systemNodes.at(i).toElement();
        System system;
        system.name = systemElement.attribute("Name");

        QDomNodeList appNodes = systemElement.elementsByTagName("Application");
        for (int j = 0; j < appNodes.size(); ++j) {
            QDomElement appElement = appNodes.at(j).toElement();
            Application app;
            app.applicationId = appElement.firstChildElement("ApplicationId").text();
            app.applicationName = appElement.firstChildElement("ApplicationName").text();
            app.applicationParameters = appElement.firstChildElement("ApplicationParameters").text();
            app.executablePath = appElement.firstChildElement("ExecutablePath").text();
            app.faultTolerance = appElement.firstChildElement("FaultTolerance").text();
            app.maxInstance = appElement.firstChildElement("MaxInstance").text();
            app.minInstance = appElement.firstChildElement("MinInstance").text();
            app.screen = appElement.firstChildElement("Screen").text();
            system.applications.append(app);
        }

        systems.append(system);
    }

    return systems;
}
