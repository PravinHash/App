#ifndef XMLPARSER_H
#define XMLPARSER_H

#include <QObject>
#include "systemmodel.h"

// XmlParser class
class XmlParser : public QObject {
    Q_OBJECT
public:
    explicit XmlParser(QObject *parent = nullptr);
    QList<System> parseXml(const QString &filePath);
};

#endif // XMLPARSER_H
