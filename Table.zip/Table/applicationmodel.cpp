#include "applicationmodel.h"

ApplicationModel::ApplicationModel(QObject *parent) : QAbstractListModel(parent) {}

void ApplicationModel::setApplications(const QList<Application> &applications) {
    beginResetModel();
    m_applications = applications;
    endResetModel();
}

int ApplicationModel::rowCount(const QModelIndex &parent) const {
    if (parent.isValid())
        return 0;
    return m_applications.size();
}

QVariant ApplicationModel::data(const QModelIndex &index, int role) const {
    if (!index.isValid() || index.row() >= m_applications.size())
        return QVariant();

    const Application &app = m_applications[index.row()];
    switch (role) {
    case ApplicationIdRole: return app.applicationId;
    case ApplicationNameRole: return app.applicationName;
    case ApplicationParametersRole: return app.applicationParameters;
    case ExecutablePathRole: return app.executablePath;
    case FaultToleranceRole: return app.faultTolerance;
    case MaxInstanceRole: return app.maxInstance;
    case MinInstanceRole: return app.minInstance;
    case ScreenRole: return app.screen;
    default: return QVariant();
    }
}

QHash<int, QByteArray> ApplicationModel::roleNames() const {
    return {
        { ApplicationIdRole, "applicationId" },
        { ApplicationNameRole, "applicationName" },
        { ApplicationParametersRole, "applicationParameters" },
        { ExecutablePathRole, "executablePath" },
        { FaultToleranceRole, "faultTolerance" },
        { MaxInstanceRole, "maxInstance" },
        { MinInstanceRole, "minInstance" },
        { ScreenRole, "screen" }
    };
}
