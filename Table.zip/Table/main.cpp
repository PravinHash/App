#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include "systemmodel.h"
#include "xmlparser.h"
#include <QQmlContext>

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    XmlParser parser;
    QList<System> systems = parser.parseXml("D:/DELHI/QT_SHARED_LIB/SHARED_LIB_IN_MAIN/Table/ApplicationConfig.xml");

    SystemModel systemModel;
    systemModel.setSystems(systems);

    engine.rootContext()->setContextProperty("systemsModel", &systemModel);


    QObject::connect(
        &engine,
        &QQmlApplicationEngine::objectCreationFailed,
        &app,
        []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);
    // engine.load(QUrl(QStringLiteral("qrc:/Main.qml")));
    engine.loadFromModule("Table", "Main");

    return app.exec();
}
