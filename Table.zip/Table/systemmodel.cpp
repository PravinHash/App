#include "systemmodel.h"

SystemModel::SystemModel(QObject *parent) : QAbstractListModel(parent) {}

void SystemModel::setSystems(const QList<System> &systems) {
    beginResetModel();
    m_systems = systems;
    endResetModel();
}

int SystemModel::rowCount(const QModelIndex &parent) const {
    if (parent.isValid())
        return 0;
    return m_systems.size();
}

QVariant SystemModel::data(const QModelIndex &index, int role) const {
    if (!index.isValid() || index.row() >= m_systems.size())
        return QVariant();

    const System &sys = m_systems[index.row()];
    switch (role) {
    case NameRole: return sys.name;
    case ApplicationsRole: {
        auto *appModel = new ApplicationModel();
        appModel->setApplications(sys.applications);
        return QVariant::fromValue(appModel);
    }
    default: return QVariant();
    }
}

QHash<int, QByteArray> SystemModel::roleNames() const {
    return {
        { NameRole, "name" },
        { ApplicationsRole, "applications" }
    };
}
