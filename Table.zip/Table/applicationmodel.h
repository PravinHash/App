#ifndef APPLICATIONMODEL_H
#define APPLICATIONMODEL_H

#include <QAbstractListModel>

struct Application {
    QString applicationId;
    QString applicationName;
    QString applicationParameters;
    QString executablePath;
    QString faultTolerance;
    QString maxInstance;
    QString minInstance;
    QString screen;
};

class ApplicationModel : public QAbstractListModel {
    Q_OBJECT

public:
    enum ApplicationRoles {
        ApplicationIdRole = Qt::UserRole + 1,
        ApplicationNameRole,
        ApplicationParametersRole,
        ExecutablePathRole,
        FaultToleranceRole,
        MaxInstanceRole,
        MinInstanceRole,
        ScreenRole
    };

    explicit ApplicationModel(QObject *parent = nullptr);

    void setApplications(const QList<Application> &applications);
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;

protected:
    QHash<int, QByteArray> roleNames() const override;

private:
    QList<Application> m_applications;
};

#endif // APPLICATIONMODEL_H
