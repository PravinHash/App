#ifndef SYSTEMMODEL_H
#define SYSTEMMODEL_H

#include <QAbstractListModel>
#include "applicationmodel.h"

struct System {
    QString name;
    QList<Application> applications;
};

class SystemModel : public QAbstractListModel {
    Q_OBJECT

public:
    enum SystemRoles {
        NameRole = Qt::UserRole + 1,
        ApplicationsRole
    };

    explicit SystemModel(QObject *parent = nullptr);

    void setSystems(const QList<System> &systems);
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;

protected:
    QHash<int, QByteArray> roleNames() const override;

private:
    QList<System> m_systems;
};

#endif // SYSTEMMODEL_H
