#include "MainScreenManager.h"
#include "QDomDocument"
#include <QDebug>
#include <QFile>
#include <QVariant>
#include <QProcess>

MainScreenManager::MainScreenManager(QObject *parent)
    : QObject{parent}
{}



QStringList MainScreenManager::extractSystemNames()
{
    QString filePath = "D:/DELHI/QT_SHARED_LIB/SHARED_LIB_IN_MAIN/Settings/ApplicationConfig.xml";
    QFile file(filePath);

    if (!file.open(QIODevice::ReadOnly)) {
        qWarning() << "Cannot open file for reading:" << filePath;
        return systemMap.keys();
    }

    QDomDocument document;
    if (!document.setContent(&file)) {
        qWarning() << "Failed to parse XML content.";
        file.close();
        return systemMap.keys();
    }

    file.close();

    QDomElement root = document.documentElement();
    QDomNodeList applications = root.elementsByTagName("Application");

    for (int i = 0; i < applications.size(); ++i) {
        QDomElement appElement = applications.at(i).toElement();

        QDomElement appNameElement = appElement.firstChildElement("ApplicationName");
        QDomElement executableElement = appElement.firstChildElement("ExecutablePath");
        QDomElement appParamsElement = appElement.firstChildElement("ApplicationParameters");

        if (!appNameElement.isNull() && !appParamsElement.isNull()) {
            QString appName = appNameElement.text();
            QString exePath = executableElement.text();
            QString appParams = appParamsElement.text();
            systemMap.insert(appName, exePath + " "+ appParams);
        }
    }

    qDebug() << "Model is " << systemMap;
    return systemMap.keys();
}


void MainScreenManager::launchApp(const QString &appName)
{
    if (!systemMap.contains(appName)) {
        qWarning() << "Application not found:" << appName;
        return;
    }

    QString appPath = systemMap[appName];
    QProcess *process = new QProcess(this);
    process->start(appPath);

    if (!process->waitForStarted()) {
        qWarning() << "Failed to start application:" << appPath;
    }

}
