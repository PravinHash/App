#ifndef MAINSCREENMANAGER_H
#define MAINSCREENMANAGER_H

#include <QObject>
#include <QMap>

class MainScreenManager : public QObject
{
    Q_OBJECT
public:
    explicit MainScreenManager(QObject *parent = nullptr);
    // Q_INVOKABLE QStringList getAppNames();
    Q_INVOKABLE void launchApp(const QString &appName);
    Q_INVOKABLE QStringList extractSystemNames();


private:
    QMap<QString, QString> systemMap; // Map of appName -> appPath
};

#endif // MAINSCREENMANAGER_H
