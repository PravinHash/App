#include "Settings.h"
#include <QQmlContext>

Settings::Settings(QObject *parent)
{

}

Settings::~Settings()
{

}

QQuickItem *Settings::createComponent(QQmlEngine *engine)
{
    QQmlComponent component(engine, QUrl(QStringLiteral("qrc:/Settings.qml")));
    if(component.status()== QQmlComponent::Error){
        qDebug() << "Error while loading Setting component " << component.errorString();
        return nullptr;
    }
    settingManager = new SettingManager();

    QQuickItem* settingItem = qobject_cast<QQuickItem*>(component.create());
    engine->rootContext()->setContextProperty("_objSettingManager", settingManager);
    return settingItem;
}
