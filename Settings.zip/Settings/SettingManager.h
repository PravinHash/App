#ifndef SETTINGMANAGER_H
#define SETTINGMANAGER_H

#include <QObject>

class SettingManager : public QObject
{
    Q_OBJECT

public:
    SettingManager();
    Q_INVOKABLE void writeDataToXML(const QVariantMap &data);

};

#endif // SETTINGMANAGER_H
