#ifndef SETTINGS_H
#define SETTINGS_H

#include "Settings_global.h"
#include <QQmlEngine>
#include <QQuickItem>
#include "D:\DELHI\QT_SHARED_LIB\ARCH\SmartMainLibrary\include\globalinterface.h"
#include "SettingManager.h"

class SETTINGS_EXPORT Settings : public QObject, public globalinterface
{
    Q_OBJECT
    Q_PLUGIN_METADATA(IID globalinterface_iid)
    Q_INTERFACES(globalinterface)

public:
    explicit Settings(QObject *parent = nullptr);
    ~Settings() override;

    virtual QQuickItem* createComponent(QQmlEngine* engine) override;

    SettingManager* settingManager;

};

#endif // SETTINGS_H
