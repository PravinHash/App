#include "SettingManager.h"
#include "QDomDocument"
#include <QDebug>
#include <QFile>
#include <QVariant>

SettingManager::SettingManager() {}
void SettingManager::writeDataToXML(const QVariantMap &data)
{

    QString filePath = "D:/DELHI/QT_SHARED_LIB/SHARED_LIB_IN_MAIN/Settings/ApplicationConfig.xml";
    QFile file(filePath);
    QDomDocument document;

    // Check if the file exists and read existing content
    if (file.exists()) {
        if (!file.open(QIODevice::ReadOnly)) {
            qWarning() << "Cannot open file for reading:" << filePath;
            return;
        }

        if (!document.setContent(&file)) {
            qWarning() << "Failed to parse existing XML content.";
            file.close();
            // return;
        }

        file.close();
    } else {
        // Create a new document if file doesn't exist
        QDomElement root = document.createElement("ApplicationDetails");
        document.appendChild(root);
    }

    // Get the root element
    QDomElement root = document.documentElement();

    // Create a new Application element
    QDomElement applicationElement = document.createElement("Application");

    for (auto it = data.begin(); it != data.end(); ++it) {
        QDomElement element = document.createElement(it.key());
        QDomText text = document.createTextNode(it.value().toString());
        element.appendChild(text);
        applicationElement.appendChild(element);
    }

    // Append the new application to the root
    root.appendChild(applicationElement);

    // Write the updated content back to the file
    if (!file.open(QIODevice::WriteOnly)) {
        qWarning() << "Cannot open file for writing:" << filePath;
        return;
    }

    QTextStream stream(&file);
    // stream.setCodec("UTF-8");
    document.save(stream, 4); // Indent with 4 spaces
    file.close();

    qDebug() << "Data successfully appended to" << filePath;
}
