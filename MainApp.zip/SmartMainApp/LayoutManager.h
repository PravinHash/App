// LayoutManager.h
#ifndef LAYOUTMANAGER_H
#define LAYOUTMANAGER_H

#include <QString>
#include <QDomDocument>
#include <QFile>
#include <QDebug>

class LayoutManager {
public:
    static QString getLayoutPath(const QString& layoutName, const QString& xmlFilePath);
};

#endif // LAYOUTMANAGER_H

