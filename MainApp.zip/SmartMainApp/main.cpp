#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQuickItem>
#include <QQmlContext>
#include <QLibrary>
#include <QDebug>
#include<QPluginLoader>
#include <QFile>
#include <QSettings>
#include <QXmlStreamReader>
#include "D:\DELHI\QT_SHARED_LIB\ARCH\SmartMainLibrary\include\ismartmainlibraryinterface.h"
#include <QDomDocument>
#include "LayoutManager.h"

int main(int argc, char *argv[]) {
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    // Load configuration
    QSettings settings("D:/DELHI/QT_SHARED_LIB/ARCH/SmartMainApp/Config.ini", QSettings::IniFormat);
    QString configFilePath = settings.value("Configuration/xmlFilePath").toString();
    QString userInputLayoutName = settings.value("Configuration/layoutName").toString();

    qDebug() << configFilePath;
    // Get the library path based on the layout name
    QString libraryPath = LayoutManager::getLayoutPath(userInputLayoutName, configFilePath);

    // Load the shared library using QPluginLoader
    if (!libraryPath.isEmpty()) {
        QPluginLoader pluginLoader(libraryPath);
        QObject* pluginInstance = pluginLoader.instance();

        if (!pluginInstance) {
            qDebug() << "Failed to load SmartMainLibrary plugin:" << pluginLoader.errorString();
        }

        // Cast the plugin to the ISmartMainLibraryInterface
        ISmartMainLibraryInterface* mainLibraryInterface = qobject_cast<ISmartMainLibraryInterface*>(pluginInstance);
        if (!mainLibraryInterface) {
            qDebug() << "The plugin does not implement ISmartMainLibraryInterface.";
        }

        // Use the interface to create the main library item
        QQuickItem* layoutItem = mainLibraryInterface->createMainLibrary(&engine, nullptr);
        if (!layoutItem) {
            qDebug() << "Failed to create main library item.";
        }

        // Expose the dynamic rectangle to QML
        engine.rootContext()->setContextProperty("dynamicRectangle", layoutItem);
    }

    const QUrl url(QStringLiteral("qrc:/SmartMainApp/Main.qml"));
    QObject::connect(
        &engine,
        &QQmlApplicationEngine::objectCreated,
        &app,
        [url](QObject *obj, const QUrl &objUrl) {
            if (!obj && url == objUrl)
                QCoreApplication::exit(-1);
        },
        Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}
