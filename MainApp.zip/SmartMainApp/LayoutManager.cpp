// LayoutManager.cpp
#include "LayoutManager.h"

QString LayoutManager::getLayoutPath(const QString& layoutName, const QString& xmlFilePath) {
    QFile file(xmlFilePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Failed to open the XML file!" << xmlFilePath;
        return QString();
    }

    QDomDocument doc;
    if (!doc.setContent(&file)) {
        qDebug() << "Failed to parse the XML content!";
        file.close();
        return QString();
    }
    file.close();

    QDomNodeList layouts = doc.elementsByTagName("Layout");
    QString defaultPath;

    for (int i = 0; i < layouts.size(); ++i) {
        QDomElement layoutElement = layouts.at(i).toElement();
        if (!layoutElement.isNull()) {
            QString name = layoutElement.attribute("Name");
            QString path = layoutElement.attribute("Path");

            if (path.isEmpty()) {
                qDebug() << "Missing Path attribute in layout:" << name;
                continue;
            }

            if (name == layoutName) {
                qDebug() << "Found layout:" << layoutName << "with Path:" << path;
                return path;
            } else if (name == "default") {
                defaultPath = path;
            }
        }
    }

    if (!defaultPath.isEmpty()) {
        qDebug() << "Using default layout as" << layoutName << "was not found.";
    } else {
        qDebug() << "No valid layout found!";
    }

    return defaultPath;
}
