#include "smartmainlibrary.h"
#include <QFile>
#include <QDomDocument>
#include <QDebug>

SmartMainLibrary::SmartMainLibrary(QObject* parent)
    : QObject(parent), m_componentManager(nullptr), m_parentRectangle(nullptr) {}

SmartMainLibrary::~SmartMainLibrary() {}

QQuickItem* SmartMainLibrary::createMainLibrary(QQmlEngine* engine, QQuickItem* parent) {


    if (!m_componentManager->loadComponentConfig() || !m_componentManager->loadLayoutConfig()) {
        return nullptr;
    }

    QQmlComponent parentComponent(engine, QUrl(QStringLiteral("qrc:/SmartMainLibraryWindow.qml")));
    m_parentRectangle = qobject_cast<QQuickItem*>(parentComponent.create());

    if (!m_parentRectangle) {
        qDebug() << "Failed to initialize parent Rectangle.";
        return nullptr;
    }

    const auto& fixedLayoutMap = m_componentManager->getFixedLayoutMap();
    for (auto it = fixedLayoutMap.begin(); it != fixedLayoutMap.end(); ++it) {
        const QString& zoneName = it.key();
        const QString& componentName = it.value();
        QQuickItem* zone = m_parentRectangle->findChild<QQuickItem*>(zoneName);

        if (zone) {
            QQuickItem* component = m_componentManager->getOrLoadComponent(componentName, m_componentManager->getComponentMap().value(componentName));
            if (component) {
                component->setParentItem(zone);
            }
        }
    }

    return m_parentRectangle;
}

void SmartMainLibrary::loadRequestedComponent(const QString &zoneName, QQuickItem *component) {
    if (!m_componentManager || !m_parentRectangle) {
        qDebug() << "ComponentManager or parentRectangle not initialized!";
        return;
    }

    QQuickItem* zone = m_parentRectangle->findChild<QQuickItem*>(zoneName);
    if (zone) {
        component->setParentItem(zone);
        component->setVisible(true);
        qDebug() << "Success " << zoneName;
    }
}

void SmartMainLibrary::unloadComponent(){
    QObject* zone = m_parentRectangle->findChild<QObject*>("popup");

    if (zone) {
        qDebug() << "Found zone4 object. Attempting to close popup...";
        // Check if the object is a Popup and invoke the close method
        bool success = QMetaObject::invokeMethod(zone, "close");
        if (success) {
            qDebug() << "Popup closed successfully.";
        } else {
            qDebug() << "Failed to invoke close on zone4.";
        }
    } else {
        qDebug() << "zone4 object not found.";
    }
}


void SmartMainLibrary::setComponentManager(IComponentManager* manager)  {
    m_componentManager = manager;

    QObject* compManagerAsObj = dynamic_cast<QObject*>(m_componentManager);
    connect(compManagerAsObj, SIGNAL(componentLoaded(QString,QQuickItem*)), this, SLOT(loadRequestedComponent(QString,QQuickItem*)));
    // connect(m_componentManager, &IComponentManager::componentUnload, this, &SmartMainLibrary::unloadComponent);
}

