#ifndef ICOMPONENTMANAGER_H
#define ICOMPONENTMANAGER_H

#include <QString>
#include <QQuickItem>
#include <QHash>
#include <QObject>

class QQmlEngine;

class IComponentManager {

public:
    virtual ~IComponentManager() = default;

    // Load configuration files for components and layouts
    virtual bool loadComponentConfig() = 0;
    virtual bool loadLayoutConfig() = 0;

    // Retrieve components
    virtual QQuickItem* getOrLoadComponent(const QString& name, const QString& path) = 0;
    virtual QQuickItem* getComponent(const QString& name) const = 0;

    // Manage components
    virtual bool addComponent(const QString& name, const QString& path) = 0;
    virtual void requestComponent(const QString& objName, const QString& zoneName) = 0;
    virtual void requestUnload() = 0;

    // Getters for layout maps
    virtual const QHash<QString, QString>& getFixedLayoutMap() const = 0;
    virtual const QHash<QString, QString>& getComponentMap() const = 0;

    // Signals to notify about component events (optional if using QObject in derived class)
    virtual void emitComponentLoaded(const QString& zoneName, QQuickItem* item) = 0;
    virtual void emitComponentReady() = 0;
    virtual void emitComponentUnload() = 0;


signals:
    virtual void componentLoaded(const QString& zoneName, QQuickItem* item) =0 ;
    virtual void componentReady() =0;
    virtual void componentUnload() =0;
};

Q_DECLARE_INTERFACE(IComponentManager, "IComponentManager")
#endif // ICOMPONENTMANAGER_H
