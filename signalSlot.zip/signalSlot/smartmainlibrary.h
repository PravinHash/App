#ifndef SMARTMAINLIBRARY_H
#define SMARTMAINLIBRARY_H

#include <QObject>
#include <QQmlEngine>
#include <QQuickItem>
#include <QPluginLoader>
#include <QQmlContext>
#include <QFile>
#include <QDomDocument>
#include "/home/darkcode/ARCH/SmartMainApp/iComponentManager.h"
#include "interfaces/ismartmainlibraryinterface.h"

class SmartMainLibrary : public QObject, public ISmartMainLibraryInterface {
    Q_OBJECT
    Q_PLUGIN_METADATA(IID ISmartMainLibraryInterface_iid)
    Q_INTERFACES(ISmartMainLibraryInterface)

public:
    explicit SmartMainLibrary(QObject* parent = nullptr);
    ~SmartMainLibrary();

    QQuickItem* createMainLibrary(QQmlEngine* engine, QQuickItem* parent = nullptr);
    void setComponentManager(IComponentManager *manager) override;

public slots:
    void loadRequestedComponent(const QString &zoneName, QQuickItem *component);
    void unloadComponent();

private:
    IComponentManager* m_componentManager;
    QQuickItem* m_parentRectangle;
};

#endif // SMARTMAINLIBRARY_H
