#include "ComponentManager.h"
#include <QFile>
#include <QDomDocument>
#include <QDebug>

// Constructor
ComponentManager::ComponentManager(QQmlEngine* engine, const QString& componentConfigPath, const QString& layoutConfigPath, QObject* parent)
    : QObject(parent), m_engine(engine),
    m_componentConfigPath(componentConfigPath),
    m_layoutConfigPath(layoutConfigPath) {}

// Load component configuration
bool ComponentManager::loadComponentConfig() {
    QFile file(m_componentConfigPath);
    if (!file.open(QIODevice::ReadOnly)) {
        qDebug() << "Failed to open component config file:" << m_componentConfigPath;
        return false;
    }

    QDomDocument doc;
    if (!doc.setContent(&file)) {
        qDebug() << "Failed to parse component config file:" << m_componentConfigPath;
        return false;
    }

    QDomNodeList nodes = doc.documentElement().elementsByTagName("Component");
    for (int i = 0; i < nodes.count(); ++i) {
        QDomElement element = nodes.item(i).toElement();
        if (!element.isNull()) {
            componentMap.insert(element.attribute("Name"), element.attribute("Path"));
        }
    }
    return true;
}

// Load layout configuration
bool ComponentManager::loadLayoutConfig() {
    QFile file(m_layoutConfigPath);
    if (!file.open(QIODevice::ReadOnly)) {
        qDebug() << "Failed to open layout config file:" << m_layoutConfigPath;
        return false;
    }

    QDomDocument doc;
    if (!doc.setContent(&file)) {
        qDebug() << "Failed to parse layout config file:" << m_layoutConfigPath;
        return false;
    }

    QDomNodeList layoutNodes = doc.documentElement().elementsByTagName("Layout");
    for (int i = 0; i < layoutNodes.count(); ++i) {
        QDomElement layoutElement = layoutNodes.item(i).toElement();
        if (!layoutElement.isNull() && layoutElement.attribute("Name") == m_layoutName) {
            fixedLayoutMap.clear();
            dynamicLayoutMap.clear();

            QDomNodeList zoneNodes = layoutElement.elementsByTagName("Zone");
            for (int j = 0; j < zoneNodes.count(); ++j) {
                QDomElement zoneElement = zoneNodes.item(j).toElement();
                if (!zoneElement.isNull()) {
                    if (zoneElement.attribute("Type") == "fixed") {
                        fixedLayoutMap.insert(zoneElement.attribute("Name"), zoneElement.attribute("Component"));
                    } else if (zoneElement.attribute("Type") == "dynamic") {
                        dynamicLayoutMap.insert(zoneElement.attribute("Name"), zoneElement.attribute("Component"));
                    }
                }
            }
            return true; // Layout found and loaded successfully
        }
    }

    qDebug() << "Layout with name" << m_layoutName << "not found in config file.";
    return false;
}

// Get or load a component
QQuickItem* ComponentManager::getOrLoadComponent(const QString& name, const QString& path) {
    if (m_componentMap.contains(name)) {
        return m_componentMap[name];
    }

    QPluginLoader* loader = new QPluginLoader(path);
    QObject* plugin = loader->instance();
    if (!plugin) {
        qDebug() << "Failed to load plugin for component:" << name << loader->errorString();
        delete loader; // Clean up loader if not used
        return nullptr;
    }

    auto* pluginInterface = qobject_cast<globalinterface*>(plugin);
    if (!pluginInterface) {
        qDebug() << "Failed to cast plugin to globalinterface for component:" << name;
        delete loader;
        return nullptr;
    }

    QQuickItem* item = pluginInterface->createComponent(m_engine);
    if (!item) {
        qDebug() << "Failed to create QQuickItem for component:" << name;
        delete loader;
        return nullptr;
    }

    m_componentMap.insert(name, item);
    loadedPlugins.insert(name, loader);
    emit componentLoaded(name, item);
    return item;
}

// Get a loaded component
QQuickItem* ComponentManager::getComponent(const QString& name) const {
    return m_componentMap.value(name, nullptr);
}

// Add a component
bool ComponentManager::addComponent(const QString& name, const QString& path) {
    if (m_componentMap.contains(name)) {
        return true; // Already loaded
    }
    return getOrLoadComponent(name, path) != nullptr;
}

// Request a component
void ComponentManager::requestComponent(const QString& objName, const QString& zoneName) {
    QString path = componentMap.value(objName);
    QQuickItem* component = getOrLoadComponent(objName, path);
    qDebug() << "requested Component " << objName ;
    emit componentLoaded(zoneName, component);

    if (!component) {
        qDebug() << "Failed to load component:" << objName;
    }
}

// Request unload
void ComponentManager::requestUnload() {
    QString componentName = "settings";

    QQuickItem* item = m_componentMap.value(componentName);
    if (!item) {
        qDebug() << "Component not found:" << componentName;
        return;
    }

    item->setParentItem(nullptr);
    item->deleteLater();
    m_componentMap.remove(componentName);

    QPluginLoader* loader = loadedPlugins.take(componentName);
    if (loader) {
        if (loader->unload()) {
            qDebug() << "Successfully unloaded plugin for component:" << componentName;
        } else {
            qDebug() << "Failed to unload plugin for component:" << componentName;
        }
        delete loader;
    }

    emit componentUnload();
}

// Getters for layout maps
const QHash<QString, QString>& ComponentManager::getFixedLayoutMap() const {
    return fixedLayoutMap;
}

const QHash<QString, QString>& ComponentManager::getComponentMap() const {
    return componentMap;
}
