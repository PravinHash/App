#ifndef COMPONENTMANAGER_H
#define COMPONENTMANAGER_H

#include <QObject>
#include <QQmlEngine>
#include <QQuickItem>
#include <QHash>
#include <QPluginLoader>
#include "iComponentManager.h"
#include "interfaces/globalinterface.h"

class ComponentManager : public QObject, public IComponentManager {
    Q_OBJECT
    Q_INTERFACES(IComponentManager)
public:
    explicit ComponentManager(QQmlEngine* engine, const QString& componentConfigPath, const QString& layoutConfigPath, QObject* parent = nullptr);

    // Interface implementation
    bool loadComponentConfig() override;
    bool loadLayoutConfig() override;
    QQuickItem* getOrLoadComponent(const QString& name, const QString& path) override;
    QQuickItem* getComponent(const QString& name) const override;
    bool addComponent(const QString& name, const QString& path) override;
    Q_INVOKABLE void requestComponent(const QString& objName, const QString& zoneName) override;
    void requestUnload() override;
    const QHash<QString, QString>& getFixedLayoutMap() const override;
    const QHash<QString, QString>& getComponentMap() const override;

    // Emit signals through interface
    void emitComponentLoaded(const QString& zoneName, QQuickItem* item) override { emit componentLoaded(zoneName, item); }
    void emitComponentReady() override { emit componentReady(); }
    void emitComponentUnload() override { emit componentUnload(); }

signals:
    void componentLoaded(const QString& zoneName, QQuickItem* item) ;
    void componentReady();
    void componentUnload();

private:
    QHash<QString, QQuickItem*> m_componentMap;
    QHash<QString, QPluginLoader*> loadedPlugins;
    QQmlEngine* m_engine;

    QString m_layoutName = "default";
    QString m_componentConfigPath;
    QString m_layoutConfigPath;

    QHash<QString, QString> componentMap;
    QHash<QString, QString> fixedLayoutMap;
    QHash<QString, QString> dynamicLayoutMap;
};

#endif // COMPONENTMANAGER_H
