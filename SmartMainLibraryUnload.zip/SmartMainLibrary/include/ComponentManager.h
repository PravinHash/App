#ifndef COMPONENTMANAGER_H
#define COMPONENTMANAGER_H

#include <QObject>
#include <QQmlEngine>
#include <QQuickItem>
#include <QPluginLoader>
#include <QHash>
#include <QDebug>
#include "D:\DELHI\QT_SHARED_LIB\ARCH\SmartMainLibrary\include\globalinterface.h"

class ComponentManager : public QObject {
    Q_OBJECT
public:
    // explicit ComponentManager(QQmlEngine* engine, QObject* parent = nullptr);
    explicit ComponentManager(QQmlEngine* engine, const QString& componentConfigPath, const QString& layoutConfigPath, QObject* parent = nullptr);

    QQuickItem* getOrLoadComponent(const QString& name, const QString& path);
    QQuickItem* getComponent(const QString& name) const;

    bool addComponent(const QString& name, const QString& path);
    Q_INVOKABLE void requestComponent(const QString& objName, const QString& zoneName);
    Q_INVOKABLE void requestUnload();

    bool loadComponentConfig();
    bool loadLayoutConfig();

    // Public getters for private members
    const QHash<QString, QString>& getFixedLayoutMap() const;
    const QHash<QString, QString>& getComponentMap() const;

signals:
    void componentLoaded(const QString& zoneName, QQuickItem* item);
    void componentReady();
    void componentUnload();

private:
    QHash<QString, QQuickItem*> m_componentMap;
    QHash<QString, QPluginLoader*> loadedPlugins;

    QQmlEngine* m_engine;

    QString m_layoutName = "default";
    QString m_componentConfigPath;
    QString m_layoutConfigPath;

    QHash<QString, QString> componentMap;
    QHash<QString, QString> fixedLayoutMap;
    QHash<QString, QString> dynamicLayoutMap;
};

#endif // COMPONENTMANAGER_H

