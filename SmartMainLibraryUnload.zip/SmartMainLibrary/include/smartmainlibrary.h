#ifndef SMARTMAINLIBRARY_H
#define SMARTMAINLIBRARY_H

#include <QObject>
#include <QQmlEngine>
#include <QQuickItem>
#include <QPluginLoader>
#include <QQmlContext>
#include <QFile>
#include <QDomDocument>
#include "ComponentManager.h"
#include "ismartmainlibraryinterface.h"

class SmartMainLibrary : public QObject, public ISmartMainLibraryInterface {
    Q_OBJECT
    Q_PLUGIN_METADATA(IID ISmartMainLibraryInterface_iid)
    Q_INTERFACES(ISmartMainLibraryInterface)

public:
    explicit SmartMainLibrary(QObject* parent = nullptr);
    ~SmartMainLibrary();

    QQuickItem* createMainLibrary(QQmlEngine* engine, QQuickItem* parent = nullptr);

public slots:
    void loadRequestedComponent(const QString &zoneName, QQuickItem *component);
    void unloadComponent();

private:
    ComponentManager* m_componentManager;
    QQuickItem* m_parentRectangle;
};

#endif // SMARTMAINLIBRARY_H
