#include "smartmainlibrary.h"
#include <QFile>
#include <QDomDocument>
#include <QDebug>

SmartMainLibrary::SmartMainLibrary(QObject* parent)
    : QObject(parent), m_componentManager(nullptr), m_parentRectangle(nullptr) {}

SmartMainLibrary::~SmartMainLibrary() {}

QQuickItem* SmartMainLibrary::createMainLibrary(QQmlEngine* engine, QQuickItem* parent) {
    // m_componentManager = new ComponentManager(engine, this);

    m_componentManager = new ComponentManager(
        engine,
        "D:/DELHI/QT_SHARED_LIB/ARCH/SmartMainLibrary/ComponentConfig.xml",
        "D:/DELHI/QT_SHARED_LIB/ARCH/SmartMainLibrary/LayoutConfig.xml",
        this
        );

    connect(m_componentManager, &ComponentManager::componentLoaded, this, &SmartMainLibrary::loadRequestedComponent);
    connect(m_componentManager, &ComponentManager::componentUnload, this, &SmartMainLibrary::unloadComponent);

    if (!m_componentManager->loadComponentConfig() || !m_componentManager->loadLayoutConfig()) {
        return nullptr;
    }

    QQmlComponent parentComponent(engine, QUrl(QStringLiteral("qrc:/SmartMainLibraryWindow.qml")));
    m_parentRectangle = qobject_cast<QQuickItem*>(parentComponent.create());

    if (!m_parentRectangle) {
        qDebug() << "Failed to initialize parent Rectangle.";
        return nullptr;
    }

    engine->rootContext()->setContextProperty("_objReqComp", m_componentManager);

    const auto& fixedLayoutMap = m_componentManager->getFixedLayoutMap();
    for (auto it = fixedLayoutMap.begin(); it != fixedLayoutMap.end(); ++it) {
        const QString& zoneName = it.key();
        const QString& componentName = it.value();
        QQuickItem* zone = m_parentRectangle->findChild<QQuickItem*>(zoneName);

        if (zone) {
            QQuickItem* component = m_componentManager->getOrLoadComponent(componentName, m_componentManager->getComponentMap().value(componentName));
            if (component) {
                component->setParentItem(zone);
            }
        }
    }

    return m_parentRectangle;
}

void SmartMainLibrary::loadRequestedComponent(const QString &zoneName, QQuickItem *component) {
    if (!m_componentManager || !m_parentRectangle) {
        qDebug() << "ComponentManager or parentRectangle not initialized!";
        return;
    }

    QQuickItem* zone = m_parentRectangle->findChild<QQuickItem*>(zoneName);
    if (zone) {
        component->setParentItem(zone);
        component->setVisible(true);
        qDebug() << "Success " << zoneName;
    }
}

void SmartMainLibrary::unloadComponent(){
    QObject* zone = m_parentRectangle->findChild<QObject*>("popup");

    if (zone) {
        qDebug() << "Found zone4 object. Attempting to close popup...";
        // Check if the object is a Popup and invoke the close method
        bool success = QMetaObject::invokeMethod(zone, "close");
        if (success) {
            qDebug() << "Popup closed successfully.";
        } else {
            qDebug() << "Failed to invoke close on zone4.";
        }
    } else {
        qDebug() << "zone4 object not found.";
    }
}


