#include "ComponentManager.h"
#include <QFile>
#include <QDomDocument>
#include <QDebug>

// ComponentManager::ComponentManager(QQmlEngine* engine, QObject* parent)
//     : QObject(parent), m_engine(engine) {}

ComponentManager::ComponentManager(QQmlEngine* engine, const QString& componentConfigPath, const QString& layoutConfigPath, QObject* parent)
    : QObject(parent), m_engine(engine),
    m_componentConfigPath(componentConfigPath),
    m_layoutConfigPath(layoutConfigPath) {}


const QHash<QString, QString>& ComponentManager::getFixedLayoutMap() const {
    return fixedLayoutMap;
}

const QHash<QString, QString>& ComponentManager::getComponentMap() const {
    return componentMap;
}


bool ComponentManager::loadComponentConfig() {
    QFile file(m_componentConfigPath);
    if (!file.open(QIODevice::ReadOnly)) {
        qDebug() << "Failed to open component config file:" << m_componentConfigPath;
        return false;
    }

    QDomDocument doc;
    if (!doc.setContent(&file)) {
        qDebug() << "Failed to parse component config file:" << m_componentConfigPath;
        return false;
    }

    QDomNodeList nodes = doc.documentElement().elementsByTagName("Component");
    for (int i = 0; i < nodes.count(); ++i) {
        QDomElement element = nodes.item(i).toElement();
        if (!element.isNull()) {
            componentMap.insert(element.attribute("Name"), element.attribute("Path"));
        }
    }
    return true;
}

bool ComponentManager::loadLayoutConfig() {
    QFile file(m_layoutConfigPath);
    if (!file.open(QIODevice::ReadOnly)) {
        qDebug() << "Failed to open layout config file:" << m_layoutConfigPath;
        return false;
    }

    QDomDocument doc;
    if (!doc.setContent(&file)) {
        qDebug() << "Failed to parse layout config file:" << m_layoutConfigPath;
        return false;
    }

    // Find the layout element corresponding to m_layoutName
    QDomNodeList layoutNodes = doc.documentElement().elementsByTagName("Layout");
    for (int i = 0; i < layoutNodes.count(); ++i) {
        QDomElement layoutElement = layoutNodes.item(i).toElement();
        if (!layoutElement.isNull() && layoutElement.attribute("Name") == m_layoutName) {
            // Clear existing maps
            fixedLayoutMap.clear();
            dynamicLayoutMap.clear();

            // Extract zones for the selected layout
            QDomNodeList zoneNodes = layoutElement.elementsByTagName("Zone");
            for (int j = 0; j < zoneNodes.count(); ++j) {
                QDomElement zoneElement = zoneNodes.item(j).toElement();
                if (!zoneElement.isNull()) {
                    if (zoneElement.attribute("Type") == "fixed") {
                        fixedLayoutMap.insert(zoneElement.attribute("Name"), zoneElement.attribute("Component"));
                    } else if (zoneElement.attribute("Type") == "dynamic") {
                        dynamicLayoutMap.insert(zoneElement.attribute("Name"), zoneElement.attribute("Component"));
                    }
                }
            }
            return true; // Layout found and loaded successfully
        }
    }

    qDebug() << "Layout with name" << m_layoutName << "not found in config file.";
    return false;
}


QQuickItem* ComponentManager::getOrLoadComponent(const QString& name, const QString& path) {
    if (m_componentMap.contains(name)) {
        return m_componentMap[name];
    }

    QPluginLoader* loader = new QPluginLoader(path);
    QObject* plugin = loader->instance();
    if (!plugin) {
        qDebug() << "Failed to load plugin for component:" << name << loader->errorString();
        return nullptr;
    }

    auto* pluginInterface = qobject_cast<globalinterface*>(plugin);
    if (!pluginInterface) {
        qDebug() << "Failed to cast plugin to globalinterface for component:" << name;
        return nullptr;
    }

    QQuickItem* item = pluginInterface->createComponent(m_engine);
    if (!item) {
        qDebug() << "Failed to create QQuickItem for component:" << name;
        return nullptr;
    }

    m_componentMap.insert(name, item);

    // Track the loaded plugin and item
    loadedPlugins.insert(name, loader);  // Now storing the heap-allocated loader

    emit componentLoaded(name, item);
    return item;
}

QQuickItem* ComponentManager::getComponent(const QString& name) const {
    return m_componentMap.value(name, nullptr);
}

bool ComponentManager::addComponent(const QString& name, const QString& path) {
    if (m_componentMap.contains(name)) {
        return true; // Already loaded
    }

    QQuickItem* item = getOrLoadComponent(name, path);
    return item != nullptr;
}

void ComponentManager::requestComponent(const QString &objName, const QString &zoneName) {
    QString path = "D:/DELHI/QT_SHARED_LIB/SHARED_LIB_IN_MAIN/Settings/build/Desktop_Qt_6_8_0_MinGW_64_bit-Release/libSettings.dll";
    QQuickItem* component = getOrLoadComponent(objName, path);
    emit componentLoaded(zoneName, component);

    qDebug() << "Request Component " << zoneName << objName;
    if (!component) {
        qDebug() << "Failed to load component:" << objName;
    }
}

void ComponentManager::requestUnload()
{
    qDebug() << "Request Unload ";

    QString componentName = "settings";

    // Check if the component is loaded
    QQuickItem* item = m_componentMap.value(componentName);
    if (!item) {
        qDebug() << "Component not found in zone:" << componentName;
        // return false;
    }

    // Remove the component item from its parent
    item->setParentItem(nullptr);
    item->deleteLater();

    // Remove the component from the hash
    m_componentMap.remove(componentName);

    // Unload the plugin
    QPluginLoader* loader = loadedPlugins.take(componentName);
    if (loader) {
        if (loader->unload()) {
            qDebug() << "Successfully unloaded plugin for component:" << componentName;
        } else {
            qDebug() << "Failed to unload plugin for component:" << componentName;
        }
        delete loader;  // Properly delete the loader
    }

    // Remove the context property
    // m_engine->rootContext()->setContextProperty(componentName.toLower(), nullptr);

    qDebug() << "Successfully unloaded component" << componentName << "from zone"; // << zoneName;

    emit componentUnload();
}
