// TrackTreeModel.cpp

#include "TrackTreeModel.h"

TrackTreeModel::TrackTreeModel(QObject *parent)
    : QAbstractItemModel(parent) {
    rootItem = new TreeItem({ {"id", "root"} });
    setupModelData();
}

TrackTreeModel::~TrackTreeModel() {
    delete rootItem;
}

int TrackTreeModel::columnCount(const QModelIndex &) const {
    return 1;
}

QVariant TrackTreeModel::data(const QModelIndex &index, int role) const {
    if (!index.isValid()) return {};

    TreeItem *item = getItem(index);
    QVariantMap d = item->data();

    switch (role) {
    case Qt::DisplayRole: return d.value("id");
    case Qt::UserRole + 1: return d.value("sensor");
    case Qt::UserRole + 2: return d.value("category");
    case Qt::UserRole + 3: return d.value("type");
    case Qt::UserRole + 4: return d;  // full data
    case Qt::UserRole + 5: return item->depth();
    default: return {};
    }
}

Qt::ItemFlags TrackTreeModel::flags(const QModelIndex &index) const {
    if (!index.isValid()) return Qt::NoItemFlags;
    return Qt::ItemIsEnabled | Qt::ItemIsSelectable;
}

QVariant TrackTreeModel::headerData(int section, Qt::Orientation orientation, int role) const {
    if (orientation == Qt::Horizontal && role == Qt::DisplayRole)
        return QString("Track ID");
    return {};
}

QModelIndex TrackTreeModel::index(int row, int column, const QModelIndex &parent) const {
    if (!hasIndex(row, column, parent)) return {};

    TreeItem *parentItem = getItem(parent);
    TreeItem *childItem = parentItem->child(row);
    return childItem ? createIndex(row, column, childItem) : QModelIndex();
}

QModelIndex TrackTreeModel::parent(const QModelIndex &index) const {
    if (!index.isValid()) return {};

    TreeItem *childItem = getItem(index);
    TreeItem *parentItem = childItem->parentItem();

    if (parentItem == rootItem) return {};
    return createIndex(parentItem->row(), 0, parentItem);
}

int TrackTreeModel::rowCount(const QModelIndex &parent) const {
    return getItem(parent)->childCount();
}

TreeItem *TrackTreeModel::getItem(const QModelIndex &index) const {
    if (index.isValid()) {
        auto *item = static_cast<TreeItem*>(index.internalPointer());
        if (item) return item;
    }
    return rootItem;
}

QHash<int, QByteArray> TrackTreeModel::roleNames() const {
    return {
        { Qt::DisplayRole, "display" },
        { Qt::UserRole + 1, "sensor" },
        { Qt::UserRole + 2, "category" },
        { Qt::UserRole + 3, "type" },
        { Qt::UserRole + 4, "fullData" },
        { Qt::UserRole + 5, "depth" }
    };
}

void TrackTreeModel::setupModelData() {
    QVariantMap track1{
        {"id", "MN001"}, {"type", "SENSOR"}, {"sensor", "Radar"}, {"category", "UNKNOWN"},
        {"parameters", QVariantMap{{"bearing", 40}, {"speed", 12}, {"course", 45}}}
    };

    QVariantMap track2{
        {"id", "RD001"}, {"type", "SENSOR"}, {"sensor", "Radar"}, {"category", "UNKNOWN"},
        {"parameters", QVariantMap{{"bearing", 45}, {"speed", 11}, {"course", 45}}}
    };

    QVariantMap track3{
        {"id", "RD003"}, {"type", "RAW"}, {"sensor", "Radar"}, {"category", "SURFACE"},
        {"parameters", QVariantMap{{"bearing", 45}, {"speed", 11}, {"course", 45}}}
    };

    QVariantMap childTrack{
        {"id", "SN003"}, {"type", "SYSTEM"}, {"sensor", "Sonar"}, {"category", "UNKNOWN"},
        {"parameters", QVariantMap{{"bearing", 30}, {"speed", 15}, {"course", 35}}}
    };

    QVariantMap parentTrack{
        {"id", "S001"}, {"type", "SYSTEM"}, {"sensor", "Sonar"}, {"category", "UNKNOWN"},
        {"parameters", QVariantMap{{"bearing", 30}, {"speed", 15}, {"course", 35}}},
        {"children", QVariantList{ childTrack }}
    };

    addTrack(track1);
    addTrack(track2);
    addTrack(track3);
    addTrack(parentTrack);
}

void TrackTreeModel::addTrack(const QVariantMap &trackData, TreeItem *parentItem) {
    if (!parentItem)
        parentItem = rootItem;

    TreeItem *trackItem = new TreeItem(trackData, parentItem);
    parentItem->appendChild(trackItem);

    if (trackData.contains("children")) {
        for (const QVariant &child : trackData["children"].toList()) {
            addTrack(child.toMap(), trackItem);
        }
    }
}


void TrackTreeModel::addTrackFromCpp(const QVariantMap &trackData) {
    if (!trackData.contains("id"))
        return;

    TreeItem *parentItem = rootItem;
    int row = parentItem->childCount();
    beginInsertRows(QModelIndex(), row, row);

    addTrack(trackData, parentItem);  // your recursive logic
    endInsertRows();
}
